#' Compute the Value of \eqn{K} for a Prediction Interval for a Normal Distribution
#' @description
#' Compute the value of \eqn{K} (the multiplier of estimated standard deviation) used
#'   to construct a prediction interval for the next \eqn{k} observations or next set of
#'   \eqn{k} means based on data from a \link[stats:Normal]{normal distribution}.
#'   The function
#'   \code{predIntNormK} is called by \code{\link{predIntNorm}}.
#' @usage
#' predIntNormK(n, df = n - 1, n.mean = 1, k = 1,
#'     method = "Bonferroni", pi.type = "two-sided",
#'     conf.level = 0.95)
#' @rawRd
#' \arguments{
#'   \item{n}{
#'   a positive integer greater than 2 indicating the sample size upon which the
#'   prediction interval is based.
#' }
#'   \item{df}{
#'   the degrees of freedom associated with the prediction interval.  The default is
#'   \code{df=n-1}.
#' }
#'   \item{n.mean}{
#'   positive integer specifying the sample size associated with the \eqn{k} future averages.
#'   The default value is \code{n.mean=1} (i.e., individual observations).  Note that all
#'   future averages must be based on the same sample size.
#' }
#'   \item{k}{
#'   positive integer specifying the number of future observations or averages the
#'   prediction interval should contain with confidence level \code{conf.level}.
#'   The default value is \code{k=1}.
#' }
#'   \item{method}{
#'   character string specifying the method to use if the number of future observations
#'   (\code{k}) is greater than 1.  The possible values are \code{method="Bonferroni"}
#'   (approximate method based on Bonferonni inequality; the default), and \cr
#'   \code{method="exact"} (exact method due to Dunnett, 1955).  See the DETAILS section for
#'   more information.  This argument is ignored if \code{k=1}.
#' }
#'   \item{pi.type}{
#'   character string indicating what kind of prediction interval to compute.
#'   The possible values are \code{pi.type="two-sided"} (the default), \code{pi.type="lower"},
#'   and \code{pi.type="upper"}.
#' }
#'   \item{conf.level}{
#'   a scalar between 0 and 1 indicating the confidence level of the prediction interval.
#'   The default value is \code{conf.level=0.95}.
#' }
#' }
#' @details
#' This help page has been shortened to keep function help focused on usage,
#' arguments, return values, and examples. Extended method details, formulas,
#' and background material are available in \code{vignette("extended-function-details", package = "EnvStats")}, section \code{predIntNormK}.
#' @rawRd
#' \value{
#'   A numeric scalar equal to \eqn{K}, the multiplier of estimated standard
#'   deviation that is used to construct the prediction interval.
#' }
#' @rawRd
#' \references{
#'   Berthouex, P.M., and L.C. Brown. (2002). \emph{Statistics for Environmental Engineers}.
#'   Lewis Publishers, Boca Raton.
#'
#'   Dunnett, C.W. (1955). A Multiple Comparisons Procedure for Comparing Several Treatments
#'   with a Control. \emph{Journal of the American Statistical Association} \bold{50}, 1096-1121.
#'
#'   Dunnett, C.W. (1964). New Tables for Multiple Comparisons with a Control.
#'   \emph{Biometrics} \bold{20}, 482-491.
#'
#'   Gibbons, R.D., D.K. Bhaumik, and S. Aryal. (2009).
#'   \emph{Statistical Methods for Groundwater Monitoring}, Second Edition.
#'   John Wiley & Sons, Hoboken.
#'
#'   Hahn, G.J. (1969). Factors for Calculating Two-Sided Prediction Intervals for
#'   Samples from a Normal Distribution.
#'   \emph{Journal of the American Statistical Association} \bold{64}(327), 878-898.
#'
#'   Hahn, G.J. (1970a). Additional Factors for Calculating Prediction Intervals for
#'   Samples from a Normal Distribution.
#'   \emph{Journal of the American Statistical Association} \bold{65}(332), 1668-1676.
#'
#'   Hahn, G.J. (1970b). Statistical Intervals for a Normal Population, Part I: Tables,
#'   Examples and Applications. \emph{Journal of Quality Technology} \bold{2}(3), 115-125.
#'
#'   Hahn, G.J. (1970c). Statistical Intervals for a Normal Population, Part II:
#'   Formulas, Assumptions, Some Derivations. \emph{Journal of Quality Technology}
#'   \bold{2}(4), 195-206.
#'
#'   Hahn, G.J., and W.Q. Meeker. (1991). \emph{Statistical Intervals: A Guide for Practitioners}.
#'   John Wiley and Sons, New York.
#'
#'   Hahn, G., and W. Nelson. (1973). A Survey of Prediction Intervals and Their Applications.
#'   \emph{Journal of Quality Technology} \bold{5}, 178-188.
#'
#'   Helsel, D.R., and R.M. Hirsch. (1992). \emph{Statistical Methods in Water Resources Research}.
#'   Elsevier, New York.
#'
#'   Helsel, D.R., and R.M. Hirsch. (2002). \emph{Statistical Methods in Water Resources}.
#'   Techniques of Water Resources Investigations, Book 4, chapter A3. U.S. Geological Survey.
#'   (available on-line at:  \url{https://pubs.usgs.gov/tm/04/a03/tm4a3.pdf}).
#'
#'   Millard, S.P., and Neerchal, N.K. (2001). \emph{Environmental Statistics with S-PLUS}.
#'   CRC Press, Boca Raton, Florida.
#'
#'   Miller, R.G. (1981a). \emph{Simultaneous Statistical Inference}. McGraw-Hill, New York.
#'
#'   USEPA. (2009).  \emph{Statistical Analysis of Groundwater Monitoring Data at RCRA Facilities, Unified Guidance}.
#'   EPA 530/R-09-007, March 2009.  Office of Resource Conservation and Recovery Program Implementation and Information Division.
#'   U.S. Environmental Protection Agency, Washington, D.C.
#'
#'   USEPA. (2010).  \emph{Errata Sheet - March 2009 Unified Guidance}.
#'   EPA 530/R-09-007a, August 9, 2010.  Office of Resource Conservation and Recovery, Program Information and Implementation Division.
#'   U.S. Environmental Protection Agency, Washington, D.C.
#' }
#' @rawRd
#' \author{
#'     Steven P. Millard (\email{EnvStats@ProbStatInfo.com})
#' }
#' @rawRd
#' \note{
#'   Prediction and tolerance intervals have long been applied to quality control and
#'   life testing problems (Hahn, 1970b,c; Hahn and Nelson, 1973).
#'   In the context of environmental statistics, prediction intervals are useful for
#'   analyzing data from groundwater detection monitoring programs at hazardous and
#'   solid waste facilities (e.g., Gibbons et al., 2009; Millard and Neerchal, 2001;
#'   USEPA, 2009).
#' }
#' @rawRd
#' \seealso{
#'   \code{\link{predIntNorm}}, \code{\link{predIntNormSimultaneous}},
#'   \code{\link{predIntLnorm}}, \code{\link{tolIntNorm}},
#'   \link{Normal}, \code{\link{estimate.object}}, \code{\link{enorm}}, \code{\link{eqnorm}}.
#' }
#' @rawRd
#' \examples{
#'   # Compute the value of K for a two-sided 95% prediction interval
#'   # for the next observation given a sample size of n=20.
#'
#'   predIntNormK(n = 20)
#'   #[1] 2.144711
#'
#'   #--------------------------------------------------------------------
#'
#'   # Compute the value of K for a one-sided upper 99% prediction limit
#'   # for the next 3 averages of order 2 (i.e., each of the 3 future
#'   # averages is based on a sample size of 2 future observations) given a
#'   # samle size of n=20.
#'
#'   predIntNormK(n = 20, n.mean = 2, k = 3, pi.type = "upper",
#'     conf.level = 0.99)
#'   #[1] 2.258026
#'
#'   #----------
#'
#'   # Compare the result above that is based on the Bonferroni method
#'   # with the exact method.
#'
#'   predIntNormK(n = 20, n.mean = 2, k = 3, method = "exact",
#'     pi.type = "upper", conf.level = 0.99)
#'   #[1] 2.251084
#'
#'   #--------------------------------------------------------------------
#'
#'   # Example 18-1 of USEPA (2009, p.18-9) shows how to construct a 95%
#'   # prediction interval for 4 future observations assuming a
#'   # normal distribution based on arsenic concentrations (ppb) in
#'   # groundwater at a solid waste landfill.  There were 4 years of
#'   # quarterly monitoring, and years 1-3 are considered background,
#'
#'   # So the sample size for the prediciton limit is n = 12,
#'   # and the number of future samples is k = 4.
#'
#'   predIntNormK(n = 12, k = 4, pi.type = "upper")
#'   #[1] 2.698976
#' }
#' @rawRd
#' \keyword{ distribution }
#' @rawRd
#' \keyword{ htest }

predIntNormK <-
function (n, df = n - 1, n.mean = 1, k = 1, method = "Bonferroni", 
    pi.type = "two-sided", conf.level = 0.95) 
{
    if (!is.vector(n, mode = "numeric") || length(n) != 1 || 
        !is.vector(df, mode = "numeric") || length(df) != 1 || 
        !is.vector(k, mode = "numeric") || length(k) != 1 || 
        !is.vector(n.mean, mode = "numeric") || length(n.mean) != 
        1 || !is.vector(conf.level, mode = "numeric") || length(conf.level) != 
        1) 
        stop("'n', 'df', 'k', 'n.mean', and 'conf.level' must be numeric scalars")
    if (n < 2) 
        stop("'n' must be greater than or equal to 2")
    if (df < 1) 
        stop("'df' must be greater than or equal to 1")
    if (k < 1) 
        stop("'k' must be greater than or equal to 1")
    if (n.mean < 1 || n.mean != trunc(n.mean)) 
        stop("'n.mean' must be an integer greater than 0")
    if (conf.level <= 0 || conf.level >= 1) 
        stop("'conf.level' must be between 0 and 1")
    method <- match.arg(method, c("Bonferroni", "exact"))
    pi.type <- match.arg(pi.type, c("two-sided", "lower", "upper"))
    Dunnetts.K(n = n, df = df, k = k, m = n.mean, method = method, 
        type = pi.type, conf.level = conf.level)
}
