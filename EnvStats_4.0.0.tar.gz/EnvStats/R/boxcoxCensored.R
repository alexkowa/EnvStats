#' Boxcox Power Transformation for Type I Censored Data
#' @rawRd \alias{Box-Cox Censored}
#' @rawRd \alias{BoxCox Censored}
#' @rawRd \alias{Box-Cox Transformation for Censored Data}
#' @rawRd \alias{BoxCox Transformation for Censored Data}
#' @description
#' Compute the value(s) of an objective for one or more Box-Cox power transformations,
#'   or to compute an optimal power transformation based on a specified objective, based on
#'   Type I censored data.
#' @usage
#' boxcoxCensored(x, censored, censoring.side = "left",
#'     lambda = {if (optimize) c(-2, 2) else seq(-2, 2, by = 0.5)}, optimize = FALSE,
#'     objective.name = "PPCC", eps = .Machine$double.eps,
#'     include.x.and.censored = TRUE, prob.method = "michael-schucany",
#'     plot.pos.con = 0.375)
#' @rawRd
#' \arguments{
#'   \item{x}{
#'   a numeric vector of positive numbers.
#'   Missing (\code{NA}), undefined (\code{NaN}), and infinite (\code{-Inf, Inf})
#'   values are allowed but will be removed.
#' }
#'   \item{censored}{
#'   numeric or logical vector indicating which values of \code{x} are censored.  This must be the
#'   same length as \code{x}.  If the mode of \code{censored} is \code{"logical"}, \code{TRUE} values
#'   correspond to elements of \code{x} that are censored, and \code{FALSE} values correspond to
#'   elements of \code{x} that are not censored.  If the mode of \code{censored} is \code{"numeric"},
#'   it must contain only \code{1}'s and \code{0}'s; \code{1} corresponds to \code{TRUE} and
#'   \code{0} corresponds to \code{FALSE}.  Missing (\code{NA}) values are allowed but will be removed.
#' }
#'   \item{censoring.side}{
#'   character string indicating on which side the censoring occurs.  The possible values are
#'   \code{"left"} (the default) and \code{"right"}.
#' }
#'   \item{lambda}{
#'   numeric vector of finite values indicating what powers to use for the
#'   Box-Cox transformation.  When \code{optimize=FALSE}, the default value is \cr
#'   \code{lambda=seq(-2, 2, by=0.5)}.  When \code{optimize=TRUE}, \code{lambda}
#'   must be a vector with two values indicating the range over which the
#'   optimization will occur and the range of these two values must include 1.
#'   In this case, the default value is \code{lambda=c(-2, 2)}.
#' }
#'   \item{optimize}{
#'   logical scalar indicating whether to simply evalute the objective function at the
#'   given values of \code{lambda} (\code{optimize=FALSE}; the default), or to compute
#'   the optimal power transformation within the bounds specified by
#'   \code{lambda} (\code{optimize=TRUE}).
#' }
#'   \item{objective.name}{
#'   character string indicating what objective to use. The possible values are
#'   \code{"PPCC"} (probability plot correlation coefficient; the default),
#'   \code{"Shapiro-Wilk"} (the Shapiro-Wilk goodness-of-fit statistic), and
#'   \code{"Log-Likelihood"} (the log-likelihood function).
#' }
#'   \item{eps}{
#'   finite, positive numeric scalar.  When the absolute value of \code{lambda} is less
#'   than \code{eps}, lambda is assumed to be 0 for the Box-Cox transformation.
#'   The default value is \code{eps=.Machine$double.eps}.
#' }
#'   \item{include.x.and.censored}{
#'   logical scalar indicating whether to include the finite, non-missing values of
#'   the argument \code{x} and the corresponding values of \code{censored} with the
#'   returned object.  The default value is \code{include.x.and.censored=TRUE}.
#' }
#'   \item{prob.method}{
#'   for multiply censored data,
#'   character string indicating what method to use to compute the plotting positions
#'   (empirical probabilities) when \cr
#'   \code{objective.name="PPCC"}.  Possible values are: \cr
#'
#'   \code{"kaplan-meier"} (product-limit method of Kaplan and Meier (1958)), \cr
#'   \code{"modified kaplan-meier"} (same as \code{"kaplan-meier"} with the maximum value included), \cr
#'   \code{"nelson"} (hazard plotting method of Nelson (1972)), \cr
#'   \code{"michael-schucany"} (generalization of the product-limit method due to Michael and Schucany (1986)), and \cr
#'   \code{"hirsch-stedinger"} (generalization of the product-limit method due to Hirsch and Stedinger (1987)). \cr
#'
#'   The default value is \code{prob.method="michael-schucany"}. \cr
#'
#'   The \code{"nelson"} method is only available for \code{censoring.side="right"}, and
#'   the \code{"modified kaplan-meier"} is only available for \code{censoring.side="left"}.
#'   See the DETAILS section for more explanation.
#'
#'   This argument is ignored if \code{objective.name} is not equal to \code{"PPCC"}
#'   and/or the data are singly censored.
#' }
#'   \item{plot.pos.con}{
#'   for multiply censored data,
#'   numeric scalar between 0 and 1 containing the value of the plotting position
#'   constant when \code{objective.name="PPCC"}.
#'   The default value is \code{plot.pos.con=0.375}.  See the DETAILS section
#'   for more information.
#'   This argument is used only if \code{prob.method} is equal to
#'   \code{"michael-schucany"} or \code{"hirsch-stedinger"}.
#'
#'   This argument is ignored if \code{objective.name} is not equal to \code{"PPCC"}
#'   and/or the data are singly censored.
#' }
#' }
#' @details
#' This help page has been shortened to keep function help focused on usage,
#' arguments, return values, and examples. Extended method details, formulas,
#' and background material are available in \code{vignette("extended-function-details", package = "EnvStats")}, section \code{boxcoxCensored}.
#' @rawRd
#' \value{
#'   \code{boxcoxCensored} returns a list of class \code{"boxcoxCensored"}
#'   containing the results.
#'   See the help file for \code{\link{boxcoxCensored.object}} for details.
#' }
#' @rawRd
#' \references{
#'   Berthouex, P.M., and L.C. Brown. (2002).
#'   \emph{Statistics for Environmental Engineers, Second Edition}.
#'   Lewis Publishers, Boca Raton, FL.
#'
#'   Box, G.E.P., and D.R. Cox. (1964).  An Analysis of Transformations
#'   (with Discussion).  \emph{Journal of the Royal Statistical Society, Series B}
#'   \bold{26}(2), 211--252.
#'
#'   Cohen, A.C. (1991).  Truncated and Censored Samples.  \emph{Marcel Dekker},
#'   New York, New York, pp.50--59.
#'
#'   Draper, N., and H. Smith. (1998). \emph{Applied Regression Analysis}. Third Edition.
#'   John Wiley and Sons, New York, pp.47-53.
#'
#'   Gilbert, R.O. (1987). \emph{Statistical Methods for Environmental Pollution
#'   Monitoring}. Van Nostrand Reinhold, NY.
#'
#'   Helsel, D.R., and R.M. Hirsch. (1992).
#'   \emph{Statistical Methods in Water Resources Research}.
#'   Elsevier, New York, NY.
#'
#'   Hinkley, D.V., and G. Runger. (1984).  The Analysis of Transformed Data
#'   (with Discussion).  \emph{Journal of the American Statistical Association}
#'   \bold{79}, 302--320.
#'
#'   Hoaglin, D.C., F.M. Mosteller, and J.W. Tukey, eds. (1983).
#'   \emph{Understanding Robust and Exploratory Data Analysis}.
#'   John Wiley and Sons, New York, Chapter 4.
#'
#'   Hoaglin, D.C. (1988).  Transformations in Everyday Experience.
#'   \emph{Chance} \bold{1}, 40--45.
#'
#'   Johnson, N. L., S. Kotz, and A.W. Kemp. (1992).  \emph{Univariate
#'   Discrete Distributions, Second Edition}.  John Wiley and Sons, New York,
#'   p.163.
#'
#'   Johnson, R.A., and D.W. Wichern. (2007).
#'   \emph{Applied Multivariate Statistical Analysis, Sixth Edition}.
#'   Pearson Prentice Hall, Upper Saddle River, NJ, pp.192--195.
#'
#'   Shumway, R.H., A.S. Azari, and P. Johnson. (1989).
#'   Estimating Mean Concentrations Under Transformations for Environmental
#'   Data With Detection Limits.  \emph{Technometrics} \bold{31}(3), 347--356.
#'
#'   Stoline, M.R. (1991).  An Examination of the Lognormal and Box and Cox
#'   Family of Transformations in Fitting Environmental Data.
#'   \emph{Environmetrics} \bold{2}(1), 85--106.
#'
#'   van Belle, G., L.D. Fisher, Heagerty, P.J., and Lumley, T. (2004).
#'   \emph{Biostatistics: A Methodology for the Health Sciences, 2nd Edition}.
#'   John Wiley & Sons, New York.
#'
#'   Zar, J.H. (2010). \emph{Biostatistical Analysis}.
#'   Fifth Edition. Prentice-Hall, Upper Saddle River, NJ,
#'   Chapter 13.
#' }
#' @rawRd
#' \author{
#'   Steven P. Millard (\email{EnvStats@ProbStatInfo.com})
#' }
#' @rawRd
#' \note{
#'   Data transformations are often used to induce normality, homoscedasticity,
#'   and/or linearity, common assumptions of parametric statistical tests and
#'   estimation procedures.  Transformations are not \dQuote{tricks} used by the
#'   data analyst to hide what is going on, but rather useful tools for
#'   understanding and dealing with data (Berthouex and Brown, 2002, p.61).
#'   Hoaglin (1988) discusses \dQuote{hidden} transformations that are used everyday,
#'   such as the pH scale for measuring acidity.  Johnson and Wichern (2007, p.192)
#'   note that "Transformations are nothing more than a reexpression of the data
#'   in different units."
#'
#'   Shumway et al. (1989) investigated extending the method of Box and Cox (1964) to
#'   the case of Type I censored data, motivated by the desire to produce estimated
#'   means and confidence intervals for air monitoring data that included censored values.
#'
#'   Stoline (1991) compared the goodness-of-fit of Box-Cox transformed data (based on
#'   using the \dQuote{optimal} power transformation from a finite set of values between
#'   -1.5 and 1.5) with log-transformed data for 17 groundwater chemistry variables.
#'   Using the Probability Plot Correlation Coefficient statistic for censored data as a
#'   measure of goodness-of-fit (see \code{\link{gofTest}}), Stoline (1991) found that
#'   only 6 of the variables were adequately modeled by a Box-Cox transformation
#'   (p >0.10 for these 6 variables).  Of these variables, five were adequately modeled
#'   by a a log transformation.  Ten of variables were \dQuote{marginally} fit by an
#'   optimal Box-Cox transformation, and of these 10 only 6 were marginally fit by a
#'   log transformation.  Based on these results, Stoline (1991) recommends checking
#'   the assumption of lognormality before automatically assuming environmental data fit
#'   a lognormal distribution.
#'
#'   One problem with data transformations is that translating results on the
#'   transformed scale back to the original scale is not always straightforward.
#'   Estimating quantities such as means, variances, and confidence limits in the
#'   transformed scale and then transforming them back to the original scale
#'   usually leads to biased and inconsistent estimates (Gilbert, 1987, p.149;
#'   van Belle et al., 2004, p.400).  For example, exponentiating the confidence
#'   limits for a mean based on log-transformed data does not yield a
#'   confidence interval for the mean on the original scale.  Instead, this yields
#'   a confidence interval for the median (see the help file for
#'   \code{\link{elnormAltCensored}}).
#'   It should be noted, however, that quantiles (percentiles) and rank-based
#'   procedures are invariant to monotonic transformations
#'   (Helsel and Hirsch, 1992, p.12).
#'
#'   Finally, there is no guarantee that a Box-Cox tranformation based on the
#'   \dQuote{optimal} value of \eqn{\lambda} will provide an adequate transformation
#'   to allow the assumption of approximate normality and constant variance.  Any
#'   set of transformed data should be inspected relative to the assumptions you
#'   want to make about it (Johnson and Wichern, 2007, p.194).
#' }
#' @rawRd
#' \seealso{
#'   \code{\link{boxcoxCensored.object}}, \code{\link{plot.boxcoxCensored}},
#'   \code{\link{print.boxcoxCensored}},
#'   \code{\link{boxcox}}, \link{Data Transformations}, \link{Goodness-of-Fit Tests}.
#' }
#' @rawRd
#' \examples{
#'   # Generate 15 observations from a lognormal distribution with
#'   # mean=10 and cv=2 and censor the observations less than 2.
#'   # Then generate 15 more observations from this distribution and
#'   # censor the observations less than 4.
#'   # Then Look at some values of various objectives for various transformations.
#'   # Note that for both the PPCC objective the optimal value is about -0.3,
#'   # whereas for the Log-Likelihood objective it is about 0.3.
#'   # (Note: the call to set.seed simply allows you to reproduce this example.)
#'
#'   set.seed(250)
#'
#'   x.1 <- rlnormAlt(15, mean = 10, cv = 2)
#'   censored.1 <- x.1 < 2
#'   x.1[censored.1] <- 2
#'
#'   x.2 <- rlnormAlt(15, mean = 10, cv = 2)
#'   censored.2 <- x.2 < 4
#'   x.2[censored.2] <- 4
#'
#'   x <- c(x.1, x.2)
#'   censored <- c(censored.1, censored.2)
#'
#'   #--------------------------
#'   # Using the PPCC objective:
#'   #--------------------------
#'
#'   boxcoxCensored(x, censored)
#'
#'   #Results of Box-Cox Transformation
#'   #Based on Type I Censored Data
#'   #---------------------------------
#'   #
#'   #Objective Name:                  PPCC
#'   #
#'   #Data:                            x
#'   #
#'   #Censoring Variable:              censored
#'   #
#'   #Censoring Side:                  left
#'   #
#'   #Censoring Level(s):              2 4
#'   #
#'   #Sample Size:                     30
#'   #
#'   #Percent Censored:                26.7%
#'   #
#'   # lambda      PPCC
#'   #   -2.0 0.8954683
#'   #   -1.5 0.9338467
#'   #   -1.0 0.9643680
#'   #   -0.5 0.9812969
#'   #    0.0 0.9776834
#'   #    0.5 0.9471025
#'   #    1.0 0.8901990
#'   #    1.5 0.8187488
#'   #    2.0 0.7480494
#'
#'
#'   boxcoxCensored(x, censored, optimize = TRUE)
#'
#'   #Results of Box-Cox Transformation
#'   #Based on Type I Censored Data
#'   #---------------------------------
#'   #
#'   #Objective Name:                  PPCC
#'   #
#'   #Data:                            x
#'   #
#'   #Censoring Variable:              censored
#'   #
#'   #Censoring Side:                  left
#'   #
#'   #Censoring Level(s):              2 4
#'   #
#'   #Sample Size:                     30
#'   #
#'   #Percent Censored:                26.7%
#'   #
#'   #Bounds for Optimization:         lower = -2
#'   #                                 upper =  2
#'   #
#'   #Optimal Value:                   lambda = -0.3194799
#'   #
#'   #Value of Objective:              PPCC = 0.9827546
#'
#'
#'   #-----------------------------------
#'   # Using the Log-Likelihodd objective
#'   #-----------------------------------
#'
#'   boxcoxCensored(x, censored, objective.name = "Log-Likelihood")
#'
#'   #Results of Box-Cox Transformation
#'   #Based on Type I Censored Data
#'   #---------------------------------
#'   #
#'   #Objective Name:                  Log-Likelihood
#'   #
#'   #Data:                            x
#'   #
#'   #Censoring Variable:              censored
#'   #
#'   #Censoring Side:                  left
#'   #
#'   #Censoring Level(s):              2 4
#'   #
#'   #Sample Size:                     30
#'   #
#'   #Percent Censored:                26.7%
#'   #
#'   # lambda Log-Likelihood
#'   #   -2.0      -95.38785
#'   #   -1.5      -84.76697
#'   #   -1.0      -75.36204
#'   #   -0.5      -68.12058
#'   #    0.0      -63.98902
#'   #    0.5      -63.56701
#'   #    1.0      -66.92599
#'   #    1.5      -73.61638
#'   #    2.0      -82.87970
#'
#'
#'   boxcoxCensored(x, censored, objective.name = "Log-Likelihood",
#'     optimize = TRUE)
#'
#'   #Results of Box-Cox Transformation
#'   #Based on Type I Censored Data
#'   #---------------------------------
#'   #
#'   #Objective Name:                  Log-Likelihood
#'   #
#'   #Data:                            x
#'   #
#'   #Censoring Variable:              censored
#'   #
#'   #Censoring Side:                  left
#'   #
#'   #Censoring Level(s):              2 4
#'   #
#'   #Sample Size:                     30
#'   #
#'   #Percent Censored:                26.7%
#'   #
#'   #Bounds for Optimization:         lower = -2
#'   #                                 upper =  2
#'   #
#'   #Optimal Value:                   lambda = 0.3049744
#'   #
#'   #Value of Objective:              Log-Likelihood = -63.2733
#'
#'   #----------
#'
#'   # Plot the results based on the PPCC objective
#'   #---------------------------------------------
#'   boxcox.list <- boxcoxCensored(x, censored)
#'   dev.new()
#'   plot(boxcox.list)
#'
#'   #Look at QQ-Plots for the candidate values of lambda
#'   #---------------------------------------------------
#'   plot(boxcox.list, plot.type = "Q-Q Plots", same.window = FALSE)
#'
#'   #==========
#'
#'   # Clean up
#'   #---------
#'   rm(x.1, censored.1, x.2, censored.2, x, censored, boxcox.list)
#'   graphics.off()
#' }
#' @rawRd
#' \keyword{ univar }
#' @rawRd
#' \keyword{ models }

boxcoxCensored <-
function (x, censored, censoring.side = "left", lambda = {
    if (optimize) 
        c(-2, 2)
    else seq(-2, 2, by = 0.5)
}, optimize = FALSE, objective.name = "PPCC", eps = .Machine$double.eps, 
    include.x.and.censored = TRUE, prob.method = "michael-schucany", 
    plot.pos.con = 0.375) 
{
    if (!is.vector(x, mode = "numeric")) 
        stop("'x' must be a numeric vector")
    if (!is.vector(censored, mode = "numeric") && !is.vector(censored, 
        mode = "logical")) 
        stop("'censored' must be a logical or numeric vector")
    if (length(censored) != length(x)) 
        stop("'censored' must be the same length as 'x'")
    if (!is.vector(lambda, mode = "numeric") || any(!is.finite(lambda))) 
        stop("'lambda' must be a numeric vector with no missing or infinite values")
    if (optimize && length(unique(lambda)) != 2) 
        stop(paste("When optimize=TRUE, 'lambda' must be a vector", 
            "with two unique values that specify the lower and", 
            "upper bounds for the optimization"))
    if (optimize && (1 < min(lambda) || 1 > max(lambda))) 
        stop("When optimize=TRUE, the range of 'lambda' must contain 1")
    data.name <- deparse(substitute(x))
    censoring.name <- deparse(substitute(censored))
    if ((bad.obs <- sum(!(ok <- is.finite(x) & is.finite(as.numeric(censored))))) > 
        0) {
        x <- x[ok]
        censored <- censored[ok]
        warning(paste(bad.obs, "observations with NA/NaN/Inf in 'x' and 'censored' removed."))
    }
    if (is.numeric(censored)) {
        if (!all(censored == 0 | censored == 1)) 
            stop(paste("When 'censored' is a numeric vector, all values of", 
                "'censored' must be 0 (not censored) or 1 (censored)."))
        censored <- as.logical(censored)
    }
    n.cen <- sum(censored)
    if (n.cen == 0) 
        stop("No censored values indicated by 'censored'.")
    x.no.cen <- x[!censored]
    if (length(unique(x.no.cen)) < 2) 
        stop("'x' must contain at least 2 non-missing, uncensored, distinct values.")
    if (any(x <= 0)) 
        stop("All non-missing, finite values of 'x' must be positive")
    objective.name <- match.arg(objective.name, c("PPCC", "Log-Likelihood"))
    censoring.side <- match.arg(censoring.side, c("left", "right"))
    multiple <- TRUE
    T.vec <- unique(x[censored])
    if (length(T.vec) == 1) {
        if (censoring.side == "left") {
            if (T.vec <= min(x.no.cen)) 
                multiple <- FALSE
        }
        else {
            if (T.vec >= max(x.no.cen)) 
                multiple <- FALSE
        }
    }
    args.list <- list(x = x, censored = censored, censoring.side = censoring.side, 
        lambda = lambda, optimize = optimize, objective.name = objective.name, 
        eps = eps, include.x.and.censored = include.x.and.censored)
    if (multiple) {
        if (objective.name == "PPCC") {
            prob.method <- match.arg(prob.method, c("michael-schucany", 
                "hirsch-stedinger", "kaplan-meier", "modified kaplan-meier", 
                "nelson"))
            if (!is.vector(plot.pos.con, mode = "numeric") || 
                length(plot.pos.con) != 1 || plot.pos.con < 0 || 
                plot.pos.con > 1) 
                stop("'plot.pos.con' must be a numeric scalar between 0 and 1")
            args.list <- c(args.list, list(prob.method = prob.method, 
                plot.pos.con = plot.pos.con))
        }
        ret.list <- do.call("boxcoxMultiplyCensored", args = args.list)
    }
    else {
        ret.list <- do.call("boxcoxSinglyCensored", args = args.list)
    }
    ret.list$data.name <- data.name
    ret.list$censoring.name <- censoring.name
    ret.list
}
